package handler

import (
	"encoding/json"
	"net/http"
	"strconv"

	"chatapp/internal/domain"
	"chatapp/internal/middleware"
	"chatapp/internal/service"
	ws "chatapp/internal/websocket"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

type AuthHandler struct {
	authService *service.AuthService
	dmService   *service.DMService
	hub         *ws.Hub
}

func NewAuthHandler(authService *service.AuthService, dmService *service.DMService, hub *ws.Hub) *AuthHandler {
	return &AuthHandler{authService: authService, dmService: dmService, hub: hub}
}

func (h *AuthHandler) Register(c *gin.Context) {
	var req domain.RegisterRequest
	if !middleware.BindJSONOrError(c, &req) {
		return
	}

	resp, err := h.authService.Register(req)
	if err != nil {
		c.JSON(http.StatusConflict, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, resp)
}

func (h *AuthHandler) Login(c *gin.Context) {
	var req domain.LoginRequest
	if !middleware.BindJSONOrError(c, &req) {
		return
	}

	resp, err := h.authService.Login(req)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, resp)
}

func (h *AuthHandler) GetProfile(c *gin.Context) {
	userID := middleware.GetUserID(c)
	user, err := h.authService.GetProfile(userID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "User not found"})
		return
	}

	c.JSON(http.StatusOK, user)
}

// SearchUsers handles GET /api/v1/users/search?q=username
func (h *AuthHandler) SearchUsers(c *gin.Context) {
	query := c.Query("q")
	userID := middleware.GetUserID(c)

	users, err := h.authService.SearchUsers(query, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Use live WebSocket connection status instead of the (possibly stale) DB flag
	for i := range users {
		users[i].IsOnline = h.hub.IsUserOnline(users[i].ID)
	}

	c.JSON(http.StatusOK, gin.H{"data": users})
}

// GET /api/v1/users/:id — view another user's public profile
func (h *AuthHandler) GetUserByID(c *gin.Context) {
	id, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid user ID"})
		return
	}

	user, err := h.authService.GetProfile(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "User not found"})
		return
	}

	// Use live WebSocket connection status instead of the (possibly stale) DB flag
	user.IsOnline = h.hub.IsUserOnline(user.ID)

	c.JSON(http.StatusOK, user)
}

// PATCH /api/v1/auth/me — update avatar and/or status
func (h *AuthHandler) UpdateProfile(c *gin.Context) {
	var req domain.UpdateProfileRequest
	if !middleware.BindJSONOrError(c, &req) {
		return
	}

	userID := middleware.GetUserID(c)
	user, err := h.authService.UpdateProfile(userID, req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Notify DM partners in real-time so their sidebar/profile reflects the change
	go h.notifyProfileUpdated(user)

	c.JSON(http.StatusOK, user)
}

func (h *AuthHandler) notifyProfileUpdated(user *domain.User) {
	partnerIDs, err := h.dmService.GetAllDMPartnerIDs(user.ID)
	if err != nil {
		return
	}

	data, err := json.Marshal(map[string]interface{}{
		"type":    string(domain.EventProfileUpdated),
		"payload": user,
	})
	if err != nil {
		return
	}

	for _, partnerID := range partnerIDs {
		h.hub.SendToUser(partnerID, data)
	}
}

// ---- Room Handler ----

type RoomHandler struct {
	roomService *service.RoomService
}

func NewRoomHandler(roomService *service.RoomService) *RoomHandler {
	return &RoomHandler{roomService: roomService}
}

func (h *RoomHandler) CreateRoom(c *gin.Context) {
	var req domain.CreateRoomRequest
	if !middleware.BindJSONOrError(c, &req) {
		return
	}

	userID := middleware.GetUserID(c)
	room, err := h.roomService.CreateRoom(req, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, room)
}

func (h *RoomHandler) GetRooms(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	if limit > 50 {
		limit = 50
	}

	result, err := h.roomService.GetRooms(page, limit)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *RoomHandler) GetRoom(c *gin.Context) {
	roomID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid room ID"})
		return
	}

	room, err := h.roomService.GetRoom(roomID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Room not found"})
		return
	}

	c.JSON(http.StatusOK, room)
}

func (h *RoomHandler) GetMyRooms(c *gin.Context) {
	userID := middleware.GetUserID(c)
	rooms, err := h.roomService.GetMyRooms(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": rooms})
}

func (h *RoomHandler) JoinRoom(c *gin.Context) {
	roomID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid room ID"})
		return
	}

	userID := middleware.GetUserID(c)
	if err := h.roomService.JoinRoom(roomID, userID); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Joined room successfully"})
}

func (h *RoomHandler) LeaveRoom(c *gin.Context) {
	roomID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid room ID"})
		return
	}

	userID := middleware.GetUserID(c)
	if err := h.roomService.LeaveRoom(roomID, userID); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Left room successfully"})
}

func (h *RoomHandler) DeleteRoom(c *gin.Context) {
	roomID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid room ID"})
		return
	}

	userID := middleware.GetUserID(c)
	if err := h.roomService.DeleteRoom(roomID, userID); err != nil {
		c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Room deleted successfully"})
}

// ---- Message Handler ----

type MessageHandler struct {
	messageService *service.MessageService
}

func NewMessageHandler(messageService *service.MessageService) *MessageHandler {
	return &MessageHandler{messageService: messageService}
}

func (h *MessageHandler) GetMessages(c *gin.Context) {
	roomID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid room ID"})
		return
	}

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))

	if limit > 100 {
		limit = 100
	}

	userID := middleware.GetUserID(c)
	result, err := h.messageService.GetMessages(roomID, userID, page, limit)
	if err != nil {
		c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *MessageHandler) EditMessage(c *gin.Context) {
	msgID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid message ID"})
		return
	}

	var req domain.EditMessageRequest
	if !middleware.BindJSONOrError(c, &req) {
		return
	}

	userID := middleware.GetUserID(c)
	message, err := h.messageService.EditMessage(msgID, userID, req)
	if err != nil {
		c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, message)
}

func (h *MessageHandler) DeleteMessage(c *gin.Context) {
	msgID, err := uuid.Parse(c.Param("id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid message ID"})
		return
	}

	userID := middleware.GetUserID(c)
	if err := h.messageService.DeleteMessage(msgID, userID); err != nil {
		c.JSON(http.StatusForbidden, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Message deleted successfully"})
}
